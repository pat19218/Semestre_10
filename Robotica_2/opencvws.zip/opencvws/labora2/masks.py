#!/home/ros2admin/opencvws/env/bin/python
import cv2
import numpy as np

def mask_red(RGB):
	# convert RGB image to chosen color space
	I = RGB
	#I = cv2.cvtColor(RGB, cv2.COLOR_BGR2HSV)
	
	#define thresholds for channel [1,2,3] based on histogram setting
	#lower_red = np.array([0.000*179, 170.000, 80.000])
	#upper_red = np.array([0.100*179, 0.750*255, 0.550*255])	
	
	lower_red = np.array([21.000, 6.000, 101.000,])
	upper_red = np.array([47.000, 65.000, 216.000])	
	
	#Create mask based on chosen histogram threshold
	mask = cv2.inRange(I, lower_red, upper_red)
	
	#Initializae output masked image based on input image
	masked_Image = cv2.bitwise_and(RGB,RGB, mask=mask)
	
	return mask, masked_Image

def mask_purple(RGB):
	# convert RGB image to chosen color space
	I = cv2.cvtColor(RGB, cv2.COLOR_BGR2HSV)
	
	#define thresholds for channel [1,2,3] based on histogram setting
	lower_purple = np.array([0.687*179, 0.300*255, 0.018*255])
	upper_purple = np.array([0.957*179, 0.566*255, 0.553*255]) #940
	
	#Create mask based on chosen histogram threshold
	mask = cv2.inRange(I, lower_purple, upper_purple)
	
	#Initializae output masked image based on input image
	masked_Image = cv2.bitwise_and(RGB,RGB, mask=mask)
	
	return mask, masked_Image

def mask_yellow(RGB):
	# convert RGB image to chosen color space
	I = cv2.cvtColor(RGB, cv2.COLOR_BGR2HSV)
	
	#define thresholds for channel [1,2,3] based on histogram setting
	lower_yellow = np.array([0.129*180, 0.551*255, 0.149*255])
	upper_yellow = np.array([0.397*180, 1.000*255, 1.000*255])	
	
	#Create mask based on chosen histogram threshold
	mask = cv2.inRange(I, lower_yellow, upper_yellow)
	
	#Initializae output masked image based on input image
	masked_Image = cv2.bitwise_and(RGB,RGB, mask=mask)
	
	return mask, masked_Image

def imfill(BW):
	im_floodfill = BW.copy()
	h, w = BW.shape[:2]
	mask = np.zeros((h+2, w+2), np.uint8)

	cv2.floodFill(im_floodfill, mask, (0,0), 255)

	#invert fllorfilled image
	im_floodfill_inv = cv2.bitwise_not(im_floodfill)

	#Combine the two images to get the foreground
	im_out = cv2.bitwise_not(BW | im_floodfill_inv)
	
	return im_out, im_floodfill_inv, im_floodfill

	
	
	


