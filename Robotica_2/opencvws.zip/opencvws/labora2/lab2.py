#!/home/ros2admin/opencvws/env/bin/python

import cv2
import numpy as np
import masks as msk
"""
Laboratorio 2 parte II

Curso: robotica 2
Nombre: Cristhofer Patzán
Carné: 19218

Detectar colores

"""

# -----------------------------------------------------------------------------
#		Cargar imagen
# -----------------------------------------------------------------------------

img = cv2.imread('res4.jpeg')

# -----------------------------------------------------------------------------
#		Mascaras
# -----------------------------------------------------------------------------

BW1, maskek_red = msk.mask_red(img)
BW2, maskek_purple = msk.mask_purple(img)
BW3, maskek_yellow = msk.mask_yellow(img)

# -----------------------------------------------------------------------------
#		negativos imfill
# -----------------------------------------------------------------------------

#im_out, im_floodfill_inv, im_floodfill
red_imfill, red_ff_inv, red_ff = msk.imfill(BW1)
purple_imfill, purple_ff_inv, purple_ff = msk.imfill(BW2)
yellow_imfill, yellow_ff_inv, yellow_ff = msk.imfill(BW3)


# -----------------------------------------------------------------------------
#		Moments
# -----------------------------------------------------------------------------

#ret, thresh = cv2.threshold(yellow_imfill, 127, 255, 0)

#---------------------------------- Amarillo-----------------------------------
#yellow_imfill = cv2.GaussianBlur(yellow_imfill, (5,5), 0)
yellow_contours, yellow_hierarchy = cv2.findContours(yellow_imfill, 1, 2)

cnt = yellow_contours[0]
#print( cnt )
M = cv2.moments(cnt)
#print( M )

yw_cx = int(M['m10']/M['m00'])
yw_cy = int(M['m01']/M['m00'])

#print("en x amarillo: ", yw_cx)
#print("en y amarillo: ", yw_cy)

#---------------------------------- rojo---------------------------------------
red_contours, red_hierarchy = cv2.findContours(red_imfill, 1, 2)

cnt = red_contours[0]
#print( cnt )
M = cv2.moments(cnt)
#print( M )

rd_cx = int(M['m10']/M['m00'])
rd_cy = int(M['m01']/M['m00'])

#print("en x rojo: ", rd_cx)
#print("en y rojo: ", rd_cy)

#----------------------------------morado--------------------------------------
purple_contours, purple_hierarchy = cv2.findContours(purple_imfill, 1, 2)

cnt = purple_contours[0]#3
area = cv2.contourArea(cnt)
#print( area)
if area < 3:
	cnt = purple_contours[3]
M = cv2.moments(cnt)
#print( M )

pl_cx = int(M['m10']/M['m00'])
pl_cy = int(M['m01']/M['m00'])

#print("en x morado: ", pl_cx)
#print("en y morado: ", pl_cy)


#------------------------------------------------------------------------------
#		Distancias absolutas
# -----------------------------------------------------------------------------
tiene_colores = 3
#--------------------------verificar si detecto color--------------------------
if np.all(purple_imfill != 0):
	pl_cx = 0
	tiene_colores -=1

if np.all(red_imfill != 0):
	rd_cx = 0
	tiene_colores -=1
	
if np.all(yellow_imfill != 0):
	yw_cx = 0
	tiene_colores -=1
	
#print("cuantos", tiene_colores)		
print("\nen x amarillo: ", yw_cx)
print("en x morado: ", pl_cx)
print("en x rojo: ", rd_cx)

#-----------------------------operacion---------------------------------------
yellow_purple_x = abs(yw_cx-pl_cx)	#Distancia menor
yellow_red_x = abs(yw_cx-rd_cx)		#Distancia mas grande

if (yellow_red_x > yellow_purple_x) and ( tiene_colores > 2):
	print("\nSi es una resistencia de 4.7 kΩ")
else:
	print("\nNo es una resistencia de 4.7 kΩ")

#-----------------------------------------------------------------------------
#		ventana prueba mascara
# -----------------------------------------------------------------------------

cv2.imshow("original", img)
cv2.imshow("rojo",red_imfill)
cv2.imshow("morado",purple_imfill)
cv2.imshow("amarillo",yellow_imfill)
#cv2.imshow("floodfilled image", red_ff)
#cv2.imshow("invertido", red_ff_inv)
#cv2.imshow("combinado", red_imfill)
cv2.waitKey(0)







